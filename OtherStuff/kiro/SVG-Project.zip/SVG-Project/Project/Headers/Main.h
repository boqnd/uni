#include <iostream>

#include "Shape.h"
#include "Line.h"
#include "Circle.h"
#include "Rectangle.h"
#include "SVG.h"
#include "String.h"

#include "../src/Shape.cpp"
#include "../src/Rectangle.cpp"
#include "../src/Circle.cpp"
#include "../src/Line.cpp"
#include "../src/SVG.cpp"



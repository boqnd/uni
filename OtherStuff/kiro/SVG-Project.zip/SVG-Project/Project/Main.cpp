#include "Headers/Main.h"

int main()
{
    SVG project;
    project.start();
}
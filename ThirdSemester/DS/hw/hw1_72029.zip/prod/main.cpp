#include <iostream>
#include "implementation.cpp"

int main() {
  startConsoleAppStore();
}

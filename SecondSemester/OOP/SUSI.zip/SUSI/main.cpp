#include "include/index.h"

int main() {
  // Program p;
  // Discipline d;
  // Discipline d1;
  // Vector<Discipline*> ds;
  // ds.push_back(&d);
  // ds.push_back(&d1);

  // d.setName("Algebra");
  // d1.setName("Geometriq");

  // String progName = "IS";
  // p.setName(progName);
  // p.setDisciplines(ds);

  // Student s;
  // String name = "Boba";
  // s.setName(name);
  // s.setFn(12345);
  // s.setProgram(&p);
  // s.enroll(72029, &p, 1);
  // s.advance();
  // s.interrupt();
  // s.graduate();
  // //s.change("program", "kn");
  // s.print();

  // Record r;
  // r.setStudent(&s);
  // r.setDiscipline(&d);
  // r.setGrade(5);

  // d.saveToFile("data/SUSI.data");
  // d1.saveToFile("data/SUSI.data");
  // p.saveToFile("data/SUSI.data");
  // s.saveToFile("data/SUSI.data");
  // r.saveToFile("data/SUSI.data");

  Controller c;
  c.start();
  // Vector<int> i;
  // i.push_back(1); 
  // i.push_back(2); 
  // i.push_back(3); 
  // i.push_back(4); 
  // i.push_back(5); 
  // i.push_back(6); 
  // i.delete_at(2);
  // i.print();

  // String str = "asdf";
  // Vector<String> words = str.split(' ');

  // for (size_t i = 0; i < words.getSize(); i++)
  // {
  //   std::cout << words[i] << std::endl;
  // }

  // c.open("data/SUSI.data");
  // c.load();
  // String newName = "BobaD";
  // c.students[0]->setName(newName);
  // //c.close();
  // c.save();
  //std::cout << c.students[0]->getProgram()->getDisciplines().getSize() << std::endl;
  // std::cout << c.disciplines.getSize() << std::endl;
  // std::cout << c.programs.getSize() << std::endl;
  // for (size_t i = 0; i < c.disciplines.getSize(); i++)
  // {
  //   std::cout<< c.disciplines[i]->getName() << std::endl;
  // }

  // std::cout<< c.programs[0]->getName() << " ";
  // for (size_t i = 0; i < c.programs[0]->getDisciplines().getSize(); i++)
  // {
  //   std::cout<< c.programs[0]->getDisciplines()[i]->getName() << " ";
  // }
  
  // Program p;

  // Student s;
  // s.setProgram(&p);

  //st.enroll(72029, "IS", 1)
    // .print()
    // .interrupt()
    // .print()
    // .resume()
    // .advance()
    // .graduate()
    //.print();
  
  return 0;
}


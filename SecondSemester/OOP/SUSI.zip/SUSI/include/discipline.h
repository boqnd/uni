#pragma once

#include <cstring>
#include <iostream>
#include <fstream>

#include "../src/model/utils/String.h"
#include "../src/model/obj/hf/discipline.h"
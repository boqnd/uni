#include <iostream>
#include <cstring>

#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "../tests/doctest.h"

#include "../src/model/obj/imp/student.cpp"
#include "../src/model/obj/imp/discipline.cpp"
#include "../src/model/obj/imp/program.cpp"
#include "../src/model/obj/imp/record.cpp"
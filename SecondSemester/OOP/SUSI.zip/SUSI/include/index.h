#pragma once

#include <iostream>
#include "../src/model/obj/imp/student.cpp"
#include "../src/model/obj/imp/discipline.cpp"
#include "../src/model/obj/imp/program.cpp"
#include "../src/model/obj/imp/record.cpp"

#include "../src/controller/controller.cpp"
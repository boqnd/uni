#pragma once

#include <cstring>
#include <iostream>
#include <fstream>

#include "../src/model/obj/imp/student.cpp"
#include "../src/model/obj/hf/discipline.h"
#include "../src/model/obj/hf/record.h"

